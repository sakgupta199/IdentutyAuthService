var sql = require('sql-query');
sqlQuery = sql.Query('mysql');
var mysql = require('mysql');
const selectId = "; SELECT LAST_INSERT_ID() AS ClientId;";
const con = mysql.createConnection({
    host: "localhost:3306",
    user: "root",
    password: "Passw0rd"
  });

var getClientId = function(name){
 var sqlInsert = sqlQuery.insert();
 var command = sqlInsert
               .into('RegisteredClient')
               .set({clientName:name})
               .build();
 command = command + selectId;
 console.log(command);
return execute(command);
}

var execute = function(command){
  console.log("1" );
  return new Promise(function(resolve,reject){
    con.connect();
      var result = con.query(command);
        con.destroy();
        resolve(result) ;
  })
}
module.exports ={
  getClientId: getClientId
}