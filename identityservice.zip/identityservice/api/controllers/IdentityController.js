'use strict';
var util = require('util');
const registerClient = require('../managers/RegisterClientManager.js');
module.exports = {
  register_client:register_client
};

function register_client(req, res) {
  var name = req.swagger.params.name.value;
  console.log("here")
  var hello = util.format('Hello, %s!', name);
  registerClient.register(name).then(function(res){
 
    res.staus(200).send(res);
  }, function(err){
    console.log("here")
    res.status(500).send({message: "err"});
  });
 //res.status(200).send({clientId:"hii", clientSecret: "hi"});
}
