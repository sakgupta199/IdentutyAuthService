const dal = require('../dal/dal');

var register = function (name) {
  return new Promise(function (resolve, reject) {
    dal.getClientId(name).then(
      function (res) {
        var client = {};
        client.clientId = parseString(res.clientId);
        client.clientSecret = "";
        resolve(client);
      },
      function (err) {
        console.log("hi" + err);
        let message = JSON.stringify(err.message);
        reject(message);
      }
    );
  });
};

module.exports = {
    register:register
}